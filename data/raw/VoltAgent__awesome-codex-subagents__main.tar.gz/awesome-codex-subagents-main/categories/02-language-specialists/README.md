# 02. Language Specialists

Language and framework specialists for ecosystem-specific implementation, debugging, and architectural guidance.

Included agents:

- `angular-architect` - Angular architecture, routing, DI, and component behavior.
- `cpp-pro` - C++ systems work with memory, concurrency, and performance sensitivity.
- `csharp-developer` - C# and .NET service or application implementation.
- `django-developer` - Django models, views, ORM, auth, and framework behavior.
- `dotnet-core-expert` - Modern .NET and ASP.NET Core implementation and review.
- `dotnet-framework-4.8-expert` - Legacy .NET Framework 4.8 compatibility-sensitive work.
- `elixir-expert` - Elixir, OTP, Phoenix, and supervised concurrency systems.
- `flutter-expert` - Flutter widgets, state, rendering, and platform integration.
- `golang-pro` - Go services, concurrency, interfaces, and operational behavior.
- `java-architect` - Java architecture and enterprise application evolution.
- `javascript-pro` - JavaScript runtime behavior and application-level implementation.
- `kotlin-specialist` - Kotlin application work, coroutines, and JVM interoperability.
- `laravel-specialist` - Laravel routing, Eloquent, queues, and validation flow.
- `nextjs-developer` - Next.js routing, rendering modes, and server/client boundaries.
- `php-pro` - PHP server-side work across frameworks and runtime behavior.
- `powershell-5.1-expert` - Windows PowerShell 5.1 legacy automation.
- `powershell-7-expert` - Modern cross-platform PowerShell automation.
- `python-pro` - Python changes, runtime issues, and packaging patterns.
- `rails-expert` - Rails models, controllers, jobs, and convention-driven changes.
- `react-specialist` - Modern React component and state-flow work.
- `rust-engineer` - Rust ownership, async runtime, and performance-sensitive work.
- `sql-pro` - Query design, SQL correctness, and migration review.
- `spring-boot-engineer` - Spring Boot services, configuration, and data access behavior.
- `swift-expert` - Swift and Apple-platform application engineering.
- `typescript-pro` - TypeScript type design, safety, and refactors.
- `vue-expert` - Vue component, composable, routing, and reactivity work.
